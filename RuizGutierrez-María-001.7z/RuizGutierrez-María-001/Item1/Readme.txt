He puesto que una vez que se borre un periódico también se borren sus xx
