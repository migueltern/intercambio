
package controllers.admin;

import java.util.Collection;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.Assert;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import services.AdminService;
import services.EntidadNuevaService;
import services.NewspaperService;
import controllers.AbstractController;
import domain.Admin;
import domain.EntidadNueva;
import domain.Newspaper;

@Controller
@RequestMapping("/entidadNueva/admin")
public class EntidadNuevaAdminController extends AbstractController {

	// Services ---------------------------------------------------------------

	@Autowired
	private EntidadNuevaService	entidadNuevaService;

	@Autowired
	private AdminService		adminService;

	@Autowired
	private NewspaperService	newspaperService;


	// Constructors -----------------------------------------------------------
	public EntidadNuevaAdminController() {

	}

	// Listing ----------------------------------------------------------------
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView result;
		Collection<EntidadNueva> muchasEntidadNueva;

		muchasEntidadNueva = this.entidadNuevaService.findAllEntidadNuevaByAdmin();

		result = new ModelAndView("entidadNueva/list");
		result.addObject("requestURI", "entidadNueva/admin/list.do");
		result.addObject("muchasEntidadNueva", muchasEntidadNueva);

		return result;
	}

	//	// Display ----------------------------------------------------------------
	//
	@RequestMapping(value = "/display", method = RequestMethod.GET)
	public ModelAndView display(@RequestParam final int entidadNuevaId) {
		ModelAndView result;
		EntidadNueva entidadNueva = new EntidadNueva();

		entidadNueva = this.entidadNuevaService.findOne(entidadNuevaId);

		result = new ModelAndView("entidadNueva/display");
		result.addObject("entidadNueva", entidadNueva);

		return result;
	}
	//
	//	//Creation-----------------------------------------------------------

	@RequestMapping(value = "/create", method = RequestMethod.GET)
	public ModelAndView create(final Newspaper newspaper) {
		ModelAndView result;
		EntidadNueva entidadNueva;
		entidadNueva = this.entidadNuevaService.create();
		result = this.createEditModelAndView(entidadNueva);
		return result;

	}

	//Edition -----------------------------------------------------------------
	@RequestMapping(value = "/edit", method = RequestMethod.GET)
	public ModelAndView edit(@RequestParam final int entidadNuevaId) {
		ModelAndView result;
		EntidadNueva entidadNueva;
		//Date now;

		Admin admin;
		//now = new Date();

		admin = this.adminService.findByPrincipal();
		entidadNueva = this.entidadNuevaService.findOne(entidadNuevaId);

		//Assert.isTrue(entidadNueva.getDisplayedMoment().after(now), "Cannot commit this operation because displayed moment is in the past");
		Assert.isTrue(entidadNueva.getDraftMode() == true, "Cannot commit this operation");
		Assert.isTrue(admin.getMuchasEntidadNueva().contains(entidadNueva), "Cannot commit this operation, because it's illegal");
		Assert.notNull(entidadNueva);
		result = this.createEditModelAndView(entidadNueva);
		result.addObject("admin", admin);
		return result;
	}
	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "save")
	public ModelAndView saveEdit(@Valid final EntidadNueva entidadNueva, final BindingResult bindingResult) {
		ModelAndView result;

		if (bindingResult.hasErrors())
			result = this.createEditModelAndView(entidadNueva);
		else
			try {
				this.entidadNuevaService.save(entidadNueva);
				result = new ModelAndView("redirect:list.do");

			} catch (final Throwable oops) {
				if (oops.getMessage().equals("displayedMoment future"))
					result = this.createEditModelAndView(entidadNueva, "entidadNueva.displayedMoment.error");
				else if (oops.getMessage().equals("modo borrador"))
					result = this.createEditModelAndView(entidadNueva, "entidadNueva.modoborrador.error");
				else if (oops.getMessage().equals("modo final"))
					result = this.createEditModelAndView(entidadNueva, "entidadNueva.modofinal.error");
				else
					result = this.createEditModelAndView(entidadNueva, "entidadNueva.commit.error");
			}

		return result;
	}
	@RequestMapping(value = "/edit", method = RequestMethod.POST, params = "delete")
	public ModelAndView delete(@ModelAttribute final EntidadNueva entidadNueva, final BindingResult bindingResult) {
		ModelAndView result;

		try {
			this.entidadNuevaService.delete(entidadNueva);
			result = new ModelAndView("redirect:list.do");
		} catch (final Throwable oops) {
			result = this.createEditModelAndView(entidadNueva, "entidadNueva.commit.error");
		}

		return result;
	}
	// Ancillary methods ------------------------------------------------------

	protected ModelAndView createEditModelAndView(final EntidadNueva entidadNueva) {
		assert entidadNueva != null;
		ModelAndView result;
		result = this.createEditModelAndView(entidadNueva, null);
		return result;
	}

	protected ModelAndView createEditModelAndView(final EntidadNueva entidadNueva, final String message) {

		assert entidadNueva != null;
		ModelAndView result;
		Collection<Newspaper> newspapers;

		newspapers = this.newspaperService.findAll();

		result = new ModelAndView("entidadNueva/edit");
		result.addObject("newspapers", newspapers);
		result.addObject("entidadNueva", entidadNueva);
		result.addObject("message", message);

		return result;

	}

}
