
package controllers;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import services.EntidadNuevaService;
import domain.EntidadNueva;

@Controller
@RequestMapping("/entidadNueva")
public class EntidadNuevaController {

	// Services---------------------------------------------------------

	@Autowired
	private EntidadNuevaService	entidadNuevaService;


	//Constructor--------------------------------------------------------
	public EntidadNuevaController() {
		super();
	}

	//Listing-----------------------------------------------------------

	@RequestMapping(value = "/list", method = RequestMethod.GET)
	public ModelAndView list(final int newspaperId) {

		ModelAndView result;
		Collection<EntidadNueva> muchasEntidadNueva;

		muchasEntidadNueva = this.entidadNuevaService.findAllPastEntidadNueva(newspaperId);

		result = new ModelAndView("entidadNueva/list");
		result.addObject("muchasEntidadNueva", muchasEntidadNueva);
		result.addObject("requestURI", "entidadNueva/list.do");

		return result;

	}
}
