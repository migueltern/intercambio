
package repositories;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import domain.EntidadNueva;

@Repository
public interface EntidadNuevaRepository extends JpaRepository<EntidadNueva, Integer> {

	//Me devuelbe todas las entidades nuevas de un admin en concreto
	@Query("select e from EntidadNueva e where e.admin.id=?1")
	Collection<EntidadNueva> findAllEntidadNuevaByAdmin(int adminId);

	//Me devuelve todas las entidades nuevas cuyo displayed moment ya ha pasado
	//dado un peri�dico
	@Query("select e from EntidadNueva e where e.displayedMoment!=null and e.newspaper.id=?1")
	Collection<EntidadNueva> findAllPastEntidadNueva(int newspaperId);
}
