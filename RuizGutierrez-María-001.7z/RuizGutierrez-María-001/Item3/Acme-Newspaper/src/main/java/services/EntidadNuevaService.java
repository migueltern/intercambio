
package services;

import java.util.Calendar;
import java.util.Collection;
import java.util.Date;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import repositories.EntidadNuevaRepository;
import domain.Admin;
import domain.EntidadNueva;

@Service
@Transactional
public class EntidadNuevaService {

	// Managed repository -----------------------------------------------------
	@Autowired
	private EntidadNuevaRepository	entidadNuevaRepository;

	// Supporting services ----------------------------------------------------

	@Autowired
	private AdminService			adminService;


	// Constructors-------------------------------------------------------

	public EntidadNuevaService() {
		super();
	}

	// Simple CRUD methods------------------------------------------------

	public EntidadNueva create() {
		Admin adminPrincipal;

		EntidadNueva result;

		result = new EntidadNueva();
		adminPrincipal = this.adminService.findByPrincipal();

		result.setDraftMode(true); // Una vez que se crea est� en modo borrador

		result.setAdmin(adminPrincipal);
		result.setTicker(this.generatedTicker());
		return result;
	}

	public EntidadNueva findOne(final int entidadNuevaId) {
		Assert.isTrue(entidadNuevaId != 0);
		EntidadNueva result;
		result = this.entidadNuevaRepository.findOne(entidadNuevaId);
		return result;
	}

	public Collection<EntidadNueva> findAll() {
		Collection<EntidadNueva> result;
		result = this.entidadNuevaRepository.findAll();
		return result;
	}

	public EntidadNueva save(final EntidadNueva entidadNueva) {
		Assert.notNull(entidadNueva);
		EntidadNueva result;
		Date now;

		now = new Date();
		result = new EntidadNueva();
		if (entidadNueva.getDisplayedMoment() != null)
			Assert.isTrue(entidadNueva.getDisplayedMoment().after(now), "displayedMoment future");

		else
			entidadNueva.setDisplayedMoment(now);
		if (!(entidadNueva.getNewspaper() == null))
			Assert.isTrue(entidadNueva.getDraftMode() == false, "modo final");
		else
			Assert.isTrue(entidadNueva.getDraftMode() == true, "modo borrador");
		//		if (entidadNueva.getDraftMode() == false)
		//			Assert.isNull(!(entidadNueva.getNewspaper() == null), "Cannot be null");

		result = this.entidadNuevaRepository.save(entidadNueva);
		Assert.notNull(result);
		return result;
	}
	public void delete(final EntidadNueva tickoff) {
		Assert.notNull(tickoff);
		Assert.isTrue(tickoff.getId() != 0);
		this.entidadNuevaRepository.delete(tickoff);
	}

	//Other business methods-----------------------------------------------------
	public Collection<EntidadNueva> findAllEntidadNuevaByAdmin() {

		Collection<EntidadNueva> result;
		Admin admin;

		admin = this.adminService.findByPrincipal();
		result = this.entidadNuevaRepository.findAllEntidadNuevaByAdmin(admin.getId());
		return result;
	}

	public Collection<EntidadNueva> findAllPastEntidadNueva(final int newspaperId) {
		Collection<EntidadNueva> result;

		result = this.entidadNuevaRepository.findAllPastEntidadNueva(newspaperId);

		return result;
	}

	public String generatedTicker() {

		Calendar calendar;

		calendar = Calendar.getInstance();
		String ticker;
		String dias;
		String mes;
		ticker = "";

		//ticker = String.valueOf(calendar.get(Calendar.YEAR)).substring(2) + String.valueOf(calendar.get(Calendar.MONTH) + 1);
		dias = String.valueOf(calendar.get(Calendar.DAY_OF_MONTH));
		mes = String.valueOf(calendar.get(Calendar.MONTH) + 1);
		if (dias.length() <= 1)
			ticker = ticker + "0" + String.valueOf(calendar.get(Calendar.DAY_OF_MONTH));
		else
			ticker = ticker + String.valueOf(calendar.get(Calendar.DAY_OF_MONTH));

		if (mes.length() <= 1)
			ticker = ticker + "0" + String.valueOf(calendar.get(Calendar.MONTH) + 1);
		else
			ticker = ticker + String.valueOf(calendar.get(Calendar.MONTH) + 1);
		ticker = ticker + String.valueOf(calendar.get(Calendar.YEAR)).substring(2);

		final char[] arr = new char[] {
			'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V',
			'W', 'X', 'Y', 'Z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9'
		};
		String cadenaAleatoria = "";
		for (Integer i = 0; i <= 1; i++) {
			final char elegido = arr[(int) (Math.random() * 62)];
			cadenaAleatoria = cadenaAleatoria + elegido;

		}

		final char[] arr2 = new char[] {
			'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V',
			'W', 'X', 'Y', 'Z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9'
		};
		String cadenaAleatoria2 = "";
		for (Integer i = 0; i <= 1; i++) {
			final char elegido = arr2[(int) (Math.random() * 62)];
			cadenaAleatoria2 = cadenaAleatoria2 + elegido;

		}

		ticker = cadenaAleatoria2 + ticker + cadenaAleatoria;

		return ticker;
	}

}
