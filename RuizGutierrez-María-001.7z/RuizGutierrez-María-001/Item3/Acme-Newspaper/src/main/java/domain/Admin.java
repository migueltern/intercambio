
package domain;

import java.util.Collection;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@Entity
@Access(AccessType.PROPERTY)
public class Admin extends Actor {

	//Relationships---------------------------------------------------------------
	private Collection<EntidadNueva>	muchasEntidadNueva;


	@OneToMany(mappedBy = "admin")
	@Valid
	@NotNull
	public Collection<EntidadNueva> getMuchasEntidadNueva() {
		return this.muchasEntidadNueva;
	}

	public void setMuchasEntidadNueva(final Collection<EntidadNueva> muchasEntidadNueva) {
		this.muchasEntidadNueva = muchasEntidadNueva;
	}

}
